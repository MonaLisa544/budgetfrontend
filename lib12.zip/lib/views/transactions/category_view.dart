import 'package:budgetfrontend/views/main_tab/back_app_bar.dart';
import 'package:budgetfrontend/views/transactions/add_transaction_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/category_controller.dart';
import '../../models/category_model.dart';
import 'add_category_view.dart';

class CategoryManagePage extends StatefulWidget {
  @override
  _CategoryManagePageState createState() => _CategoryManagePageState();
}

class _CategoryManagePageState extends State<CategoryManagePage>
    with SingleTickerProviderStateMixin {
  final CategoryController controller = Get.put(CategoryController());
  late TabController _tabController;
  String selectedType = 'expense';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    controller.loadCategories(selectedType);

    _tabController.addListener(() {
      if (_tabController.indexIsChanging) return;
      setState(() {
        selectedType = _tabController.index == 0 ? 'expense' : 'income';
      });
      controller.loadCategories(selectedType);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: BackAppBar(title: 'Categories'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(32),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(32),
                ),
                labelColor: Colors.white,
                unselectedLabelColor: Colors.black,
                tabs: const [
                  Tab(text: 'EXPENSES'),
                  Tab(text: 'INCOME'),
                ],
              ),
            ),
          ),
          Expanded(
            child: Obx(() {
              final categories = controller.categories
                  .where((cat) => cat.transactionType == selectedType)
                  .toList();
              return ListView.builder(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: categories.length,
                itemBuilder: (_, index) {
                  final cat = categories[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: ListTile(
                        leading: Icon(cat.iconData, color: cat.safeColor),
                        title: Text(
                          cat.categoryName,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        trailing: PopupMenuButton(
                          onSelected: (value) async {
                            if (value == 'edit') {
                              final result = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => AddCategoryView(
                                    isEdit: true,
                                    category: cat,
                                  ),
                                ),
                              );
                              if (result == true) {
                                controller.loadCategories(selectedType);
                              }
                            } else if (value == 'delete') {
                              await controller.deleteCategory(cat.id!);
                              controller.loadCategories(selectedType);
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text('Edit')),
                            PopupMenuItem(value: 'delete', child: Text('Delete')),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(48),
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text('OK'),
                  ),
                ),
                const SizedBox(width: 10),
                FloatingActionButton(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AddCategoryView(
                          isEdit: false,
                          category: null,
                        ),
                      ),
                    );
                    if (result == true) {
                      controller.loadCategories(selectedType);
                    }
                  },
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.add),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
