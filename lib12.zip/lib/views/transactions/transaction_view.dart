import 'dart:ui';
import 'package:budgetfrontend/models/category_model.dart';
import 'package:budgetfrontend/models/transaction_model.dart';
import 'package:budgetfrontend/views/main_tab/main_bar_view.dart';
import 'package:budgetfrontend/views/transactions/add_transaction_view.dart';
import 'package:budgetfrontend/views/transactions/category_selecter_dialog.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:get/get.dart';
import 'package:budgetfrontend/controllers/transaction_controller.dart';
import 'package:budgetfrontend/views/transactions/date_range_picker_dialog.dart';

class TransactionView extends StatefulWidget {
  const TransactionView({super.key});

  @override
  State<TransactionView> createState() => _TransactionViewState();
}

class _TransactionViewState extends State<TransactionView> {
  String selectedType = 'All';
  String selectedWallet = 'Private Wallet';
  DateTime? selectedDate;
  bool _isAddedTransaction = false;
  CategoryModel? selectedCategory;

  final transactionController = Get.put(TransactionController());
  DateTime? startDate;
  DateTime? endDate;

  @override
  void initState() {
    super.initState();
    startDate = DateTime.now().subtract(const Duration(days: 7));
    endDate = DateTime.now();
    transactionController.loadTransactions();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: MainBarView(
        title: 'Transactions',
        onNotfPressed: () {},
        onProfilePressed: () {},
      ),
      floatingActionButton:
          _isAddedTransaction
              ? Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6.0),
                    child: FloatingActionButton.extended(
                      heroTag: 'income',
                      onPressed: () {
                        setState(() => _isAddedTransaction = false);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (context) => AddTransactionView(type: 'income'),
                          ),
                        );
                      },
                      backgroundColor: Colors.lightBlue.shade100,
                      icon: Icon(Icons.trending_up, color: Colors.green),
                      label: const Text(
                        'Income',
                        style: TextStyle(color: Colors.black),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6.0),
                    child: FloatingActionButton.extended(
                      heroTag: 'expense',
                      onPressed: () {
                        setState(() => _isAddedTransaction = false);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (context) =>
                                    AddTransactionView(type: 'expense'),
                          ),
                        );
                      },
                      backgroundColor: Colors.lightBlue.shade100,
                      icon: Icon(Icons.trending_down, color: Colors.red),
                      label: const Text(
                        'Expense',
                        style: TextStyle(color: Colors.black),
                      ),
                    ),
                  ),
                  FloatingActionButton(
                    heroTag: 'close',
                    onPressed:
                        () => setState(() => _isAddedTransaction = false),
                    backgroundColor: const Color.fromARGB(
                      255,
                      252,
                      75,
                      52,
                    ).withOpacity(0.7),
                    child: const Icon(Icons.close),
                  ),
                ],
              )
              : FloatingActionButton(
                heroTag: 'main',
                onPressed: () => setState(() => _isAddedTransaction = true),
                backgroundColor: Colors.green,
                child: const Icon(Icons.add),
              ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/background/background14.jpeg', fit: BoxFit.cover),
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 99, sigmaY: 50),
              child: Container(color: Colors.transparent),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Color.fromARGB(255, 57, 186, 196),
                  ],
                  stops: [0.5, 1.0],
                ),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.only(
                  top: 8,
                  left: 16,
                  right: 16,
                  bottom: 10,
                ),
                child: Obx(() {
                  final transactions =
                      transactionController.transactions.where((txn) {
                        //if (selectedType != 'All' && txn.transactionType != selectedType) return false;
                        if (selectedWallet == 'Private Wallet' &&
                            txn.walletId != 2)
                          return false;
                        if (selectedWallet == 'Family Wallet' &&
                            txn.walletId != 1)
                          return false;
                        if (selectedDate != null &&
                            DateFormat(
                                  'yyyy-MM-dd',
                                ).format(txn.transactionDate) !=
                                DateFormat('yyyy-MM-dd').format(selectedDate!))
                          return false;
                        return true;
                      }).toList();

                  final balances = calculateBalances(
                    transactionController.transactions,
                  );

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      DefaultTabController(
                        length: 2,
                        child: Column(
                          children: [
                            TabBar(
                              indicatorColor: Colors.white,
                              labelColor: Colors.white,
                              unselectedLabelColor: Colors.white60,
                              tabs: const [
                                Tab(text: "Private Wallet"),
                                Tab(text: "Family Wallet"),
                              ],
                              onTap: (index) {
                                setState(() {
                                  selectedWallet =
                                      [
                                        'Private Wallet',
                                        'Family Wallet',
                                      ][index];
                                });
                              },
                            ),
                            const SizedBox(height: 10),
                            balanceDisplay(balances),
                            TextButton.icon(
                              icon: const Icon(
                                Icons.calendar_month,
                                color: Color.fromARGB(255, 157, 245, 162),
                              ),
                              label: Text(
                                startDate != null && endDate != null
                                    ? "${DateFormat('yyyy-MM-dd').format(startDate!)} → ${DateFormat('yyyy-MM-dd').format(endDate!)}"
                                    : "🗓️ Хугацаа сонгох",
                                style: const TextStyle(
                                  color: Color.fromARGB(255, 157, 245, 162),
                                ),
                              ),
                              onPressed: () async {
                                final picked = await showDialog<List<DateTime>>(
                                  context: context,
                                  builder:
                                      (context) => TimelineDateRangeDialog(
                                        initialStart: startDate,
                                        initialEnd: endDate,
                                      ),
                                );

                                if (picked != null && picked.length == 2) {
                                  setState(() {
                                    startDate = picked[0];
                                    endDate = picked[1];
                                  });
                                }
                              },
                            ),

                            walletSummary(balances),
                            filterChips(),
                            TextButton.icon(
                              icon: Icon(Icons.category),
                              label: Text(
                                selectedCategory?.categoryName ??
                                    'Ангилал сонгох',
                                style: const TextStyle(color: Colors.white),
                              ),
                              onPressed: () async {
                                final selected =
                                    await showCategorySelectorDialogByType(
                                      context: context,
                                      type:
                                          selectedType
                                              .toLowerCase(), // 'income' эсвэл 'expense'
                                      selectedCategory: selectedCategory,
                                    );
                                if (selected != null) {
                                  setState(() => selectedCategory = selected);
                                }
                              },
                            ),

                            transactionList(transactions),
                          ],
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget balanceDisplay(Map<String, double> balances) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Text(
            'Balance:  ',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            "\$${balances[selectedWallet]!.toStringAsFixed(2)}",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget walletSummary(Map<String, double> balances) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        walletCard(
          "Нийт орлого:",
          Icons.arrow_upward,
          balances[selectedWallet]!,
        ),
        SizedBox(width: 10),
        walletCard(
          "Нийт зарлага:",
          Icons.arrow_downward,
          balances[selectedWallet]!,
        ),
      ],
    );
  }

  Widget walletCard(String label, IconData icon, double value) {
    return Container(
      height: 60,
      width: 135,
      padding: EdgeInsets.symmetric(horizontal: 7, vertical: 10),
      decoration: BoxDecoration(
        color: Color.fromARGB(221, 67, 107, 167).withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 14, color: Colors.white),
              SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
          SizedBox(height: 5),
          Text(
            "\$${value.toStringAsFixed(2)} MNT",
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget filterChips() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      child: Container(
        height: 35,
        decoration: BoxDecoration(
          border: Border.all(
            color: const Color.fromARGB(255, 197, 197, 197).withOpacity(0.5), // хүрээний өнгө
            width: 1.5, // хүрээний зузаан
          ),
          color: const Color.fromARGB(255, 1, 5, 24),
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Color.fromARGB(255, 0, 0, 0),
              blurRadius: 10,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children:
              ['All', 'Income', 'Expense'].map((type) {
                return ChoiceChip(
                  label: Text(
                    type,
                    style: TextStyle(
                      color: selectedType == type ? Colors.white : Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  selected: selectedType == type,
                  selectedColor: Colors.green,
                  backgroundColor: const Color.fromARGB(255, 1, 5, 24),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  onSelected: (_) => setState(() => selectedType = type),
                );
              }).toList(),
        ),
      ),
    );
  }

  Widget transactionList(List<TransactionModel> transactions) {
    return Container(
      padding: EdgeInsets.only(bottom: 200),
      //   decoration: BoxDecoration(
      //      border: Border.all(
      //   color: const Color.fromARGB(255, 255, 255, 255).withOpacity(0.75), // хүрээний өнгө
      //   width: 1.5,          // хүрээний зузаан
      // ),

      //     //color: Colors.white,
      //     borderRadius: BorderRadius.circular(40),
      //   ),
      child: Column(
        children: [
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: transactions.length,
            itemBuilder: (context, index) {
              final txn = transactions[index];
              bool isIncome = txn.transactionType == 'Income';
              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                elevation: 4,
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor:
                        txn.walletId == 1
                            ? Colors.blueAccent
                            : Colors.orangeAccent,
                    child: Icon(
                      getWalletIcon(txn.walletId),
                      color: Colors.white,
                    ),
                  ),
                  title: Text(
                    txn.transactionName,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    "${getWalletName(txn.walletId)} • ${DateFormat('yyyy-MM-dd').format(txn.transactionDate)}",
                    style: TextStyle(color: Colors.black54, fontSize: 12),
                  ),
                  trailing: Text(
                    (isIncome ? "+" : "-") +
                        "\$${txn.transactionAmount.toStringAsFixed(2)}",
                    style: TextStyle(
                      color: isIncome ? Colors.greenAccent : Colors.redAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Map<String, double> calculateBalances(List<TransactionModel> transactions) {
    double familyBalance = 0.0;
    double privateBalance = 0.0;
    for (var txn in transactions) {
      if (txn.walletId == 1) {
        familyBalance +=
            txn.transactionType == 'Income'
                ? txn.transactionAmount
                : -txn.transactionAmount;
      } else if (txn.walletId == 2) {
        privateBalance +=
            txn.transactionType == 'Income'
                ? txn.transactionAmount
                : -txn.transactionAmount;
      }
    }
    return {'Family Wallet': familyBalance, 'Private Wallet': privateBalance};
  }

  String getWalletName(int walletId) {
    if (walletId == 1) return 'Family Wallet';
    if (walletId == 2) return 'Private Wallet';
    return 'Unknown';
  }

  IconData getWalletIcon(int walletId) {
    if (walletId == 1) return Icons.group;
    if (walletId == 2) return Icons.person;
    return Icons.help_outline;
  }
}
