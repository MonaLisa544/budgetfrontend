import 'dart:convert';
import 'package:budgetfrontend/models/category_model.dart';
import 'package:budgetfrontend/models/transaction_model.dart';
import 'package:budgetfrontend/services/auth_service.dart';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://172.16.151.5:3001/api/v1';

  static Future<Map<String, String>> get headers async {
    final token = await AuthService.getToken();
    return {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  // ------------------- TRANSACTIONS -------------------

  static Future<List<TransactionModel>> getTransactions() async {
    final response = await http.get(
      Uri.parse('$baseUrl/transactions'),
      headers: await headers,
    );

    if (response.statusCode == 200) {
      final List body = jsonDecode(response.body);
      return body.map((e) => TransactionModel.fromJson(e)).toList();
    } else {
      throw Exception('Гүйлгээ татаж чадсангүй');
    }
  }

  static Future<TransactionModel?> postTransaction(TransactionModel txn) async {
    final response = await http.post(
      Uri.parse('$baseUrl/transactions'),
      headers: await headers,
      body: jsonEncode(txn.toJson()),
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      return TransactionModel.fromJson(jsonDecode(response.body));
    } else {
      print('Гүйлгээ үүсгэхэд алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return null;
    }
  }

  static Future<TransactionModel?> getTransactionById(int id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/transactions/$id'),
      headers: await headers,
    );

    if (response.statusCode == 200) {
      return TransactionModel.fromJson(jsonDecode(response.body));
    } else {
      print('Гүйлгээ харахад алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return null;
    }
  }

  static Future<TransactionModel?> updateTransaction(TransactionModel txn) async {
    final response = await http.put(
      Uri.parse('$baseUrl/transactions/${txn.id}'),
      headers: await headers,
      body: jsonEncode(txn.toJson()),
    );

    if (response.statusCode == 200) {
      return TransactionModel.fromJson(jsonDecode(response.body));
    } else {
      print('Гүйлгээ шинэчлэхэд алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return null;
    }
  }

  static Future<bool> deleteTransaction(int id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/transactions/$id'),
      headers: await headers,
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Гүйлгээ устгах үед алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return false;
    }
  }

  // ------------------- CATEGORIES -------------------

  // static Future<List<CategoryModel>> getCategories(String type) async {
  //   final response = await http.get(
  //     Uri.parse('$baseUrl/categories?transaction_type=$type'),
  //     headers: await headers,
  //   );

  //   if (response.statusCode == 200) {
  //     final List data = jsonDecode(response.body);
  //     return data.map((e) => CategoryModel.fromJson(e)).toList();
  //   } else {
  //     throw Exception('Категори татаж чадсангүй');
  //   }
  // }

  static Future<List<CategoryModel>> getCategories(String type) async {
  final response = await http.get(
    Uri.parse('$baseUrl/categories?type=$type'),
    headers: await headers,
  );

  print('🔎 Response Status: ${response.statusCode}');
  print('📦 Body: ${response.body}');

  if (response.statusCode == 200) {
    final json = jsonDecode(response.body);

    // Хэрэв json нь List бол шууд
    if (json is List) {
      return json.map((e) => CategoryModel.fromJson(e)).toList();
    }

    // Хэрэв json нь Map бөгөөд "data" түлхүүртэй бол
    if (json is Map && json['data'] is List) {
      return (json['data'] as List)
          .map((e) => CategoryModel.fromJson(e))
          .toList();
    }

    throw Exception('⚠️ Unknown JSON structure');
  } else {
    throw Exception('Категори татаж чадсангүй');
  }
}

  static Future<CategoryModel?> createCategory(CategoryModel category) async {
    final response = await http.post(
      Uri.parse('$baseUrl/categories'),
      headers: await headers,
      body: jsonEncode(category.toJson()),
    );

    if (response.statusCode == 201 || response.statusCode == 200) {
      return CategoryModel.fromJson(jsonDecode(response.body));
    } else {
      print('Категори үүсгэхэд алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return null;
    }
  }

  static Future<CategoryModel?> getCategoryById(int id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/categories/$id'),
      headers: await headers,
    );

    if (response.statusCode == 200) {
      return CategoryModel.fromJson(jsonDecode(response.body));
    } else {
      print('Категори харахад алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return null;
    }
  }

  static Future<CategoryModel?> updateCategory(CategoryModel category) async {
    final response = await http.put(
      Uri.parse('$baseUrl/categories/${category.id}'),
      headers: await headers,
      body: jsonEncode(category.toJson()),
    );

    if (response.statusCode == 200) {
      return CategoryModel.fromJson(jsonDecode(response.body));
    } else {
      print('Категори шинэчлэхэд алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return null;
    }
  }

  static Future<bool> deleteCategory(int id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/categories/$id'),
      headers: await headers,
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Категори устгах үед алдаа гарлаа: ${response.statusCode} - ${response.body}');
      return false;
    }
  }
}
