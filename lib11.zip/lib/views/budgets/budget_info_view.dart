import 'package:flutter/material.dart';

class BudgetInfoView extends StatefulWidget {
  const BudgetInfoView({super.key});

  @override
  State<BudgetInfoView> createState() => _BudgetInfoViewState();
}

class _BudgetInfoViewState extends State<BudgetInfoView> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}