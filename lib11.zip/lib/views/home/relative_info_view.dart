import 'package:flutter/material.dart';

class RelativeInfoView extends StatefulWidget {
  const RelativeInfoView({super.key});

  @override
  State<RelativeInfoView> createState() => _RelativeInfoViewState();
}

class _RelativeInfoViewState extends State<RelativeInfoView> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}