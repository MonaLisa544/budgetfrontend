import 'package:flutter/material.dart';

class RelativeView extends StatefulWidget {
  const RelativeView({super.key});

  @override
  State<RelativeView> createState() => _RelativeViewState();
}

class _RelativeViewState extends State<RelativeView> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}