class TransactionModel {
  final int? id;
  final String transactionName;
  final double transactionAmount;
  final String? transactionType; // Optional if it's derived from category
  final int walletId;
  final int categoryId;
  final DateTime transactionDate;
  final String? description;

  TransactionModel({
    this.id,
    required this.transactionName,
    required this.transactionAmount,
    this.transactionType,
    required this.walletId,
    required this.categoryId,
    required this.transactionDate,
    this.description,
  });

  // JSON -> TransactionModel
  factory TransactionModel.fromJson(Map<String, dynamic> json) {
    return TransactionModel(
      id: json['id'],
      transactionName: json['transaction_name'],
      transactionAmount: (json['transaction_amount'] as num).toDouble(),
      //transactionType: json['transaction_type'], // Optional
      walletId: json['wallet_id'],
      categoryId: json['category_id'],
      transactionDate: DateTime.parse(json['transaction_date']),
      description: json['description'],
    );
  }

  // TransactionModel -> JSON
  Map<String, dynamic> toJson() {
    return {
      'transaction_name': transactionName,
      'transaction_amount': transactionAmount,
      //'transaction_type': transactionType,
      'wallet_id': walletId,
      'category_id': categoryId,
      'transaction_date': transactionDate.toIso8601String(),
      'description': description,
    };
  }

  // Copy with (for updates)
  TransactionModel copyWith({
    int? id,
    String? transactionName,
    double? transactionAmount,
    //String? transactionType,
    int? walletId,
    int? categoryId,
    DateTime? transactionDate,
    String? description,
  }) {
    return TransactionModel(
      id: id ?? this.id,
      transactionName: transactionName ?? this.transactionName,
      transactionAmount: transactionAmount ?? this.transactionAmount,
      //transactionType: transactionType ?? this.transactionType,
      walletId: walletId ?? this.walletId,
      categoryId: categoryId ?? this.categoryId,
      transactionDate: transactionDate ?? this.transactionDate,
      description: description ?? this.description,
    );
  }
}
